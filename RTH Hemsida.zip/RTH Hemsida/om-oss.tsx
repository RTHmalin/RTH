import { createFileRoute } from "@tanstack/react-router";
import { Heart, MapPin, ShieldCheck, Award, Users, Target, Eye, Sparkles } from "lucide-react";
import vanImg from "@/assets/service-van.jpg";
import { PageHero } from "@/components/site/PageHero";
import { SectionHeading } from "@/components/site/SectionHeading";
import { Testimonials } from "@/components/site/Testimonials";
import { CtaBand } from "@/components/site/CtaBand";

export const Route = createFileRoute("/om-oss")({
  head: () => ({
    meta: [
      { title: "Om oss | RTH i Orsa AB – Orsa, Dalarna" },
      {
        name: "description",
        content:
          "RTH är ett lokalt familjeföretag i Orsa, Dalarna. Vi står för säkerhet, kvalitet och personlig elservice för hem och företag i hela Dalarna.",
      },
      { property: "og:title", content: "Om RTH i Orsa AB" },
      { property: "og:description", content: "Lokalt familjeföretag med fokus på säkerhet och kvalitet." },
    ],
  }),
  component: AboutPage,
});

const values = [
  { icon: ShieldCheck, title: "Säkerhet", text: "All el utförs enligt gällande regelverk – din trygghet är vår högsta prioritet." },
  { icon: Award, title: "Kvalitet", text: "Vi nöjer oss aldrig med mindre än ett hållbart och välgjort arbete." },
  { icon: Heart, title: "Service", text: "Personligt bemötande och snabb hjälp – som det ska vara hos ett lokalt företag." },
  { icon: Users, title: "Lokal närvaro", text: "Vi finns mitt i Dalarna och känner vår bygd och våra kunder." },
];

const certs = ["Behörig elinstallatör", "Auktoriserad elfirma", "Försäkrat arbete", "ROT & Grön teknik"];

function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="Om oss"
        title="Ditt lokala familjeföretag inom el"
        description="RTH i Orsa AB är ett familjeägt elföretag i Orsa. Vi hjälper privatpersoner och företag i hela Dalarna med trygg, kvalitativ och personlig elservice."
      />

      <section className="container-px grid items-center gap-10 py-16 lg:grid-cols-2">
        <div className="overflow-hidden rounded-3xl shadow-[var(--shadow-elevated)]">
          <img src={vanImg} alt="RTH servicebil i Dalarna" width={1200} height={900} loading="lazy" className="h-full w-full object-cover" />
        </div>
        <div>
          <SectionHeading align="left" eyebrow="Vår historia" title="Byggt på hantverk och förtroende" />
          <div className="mt-5 space-y-4 text-muted-foreground">
            <p>
              Med rötterna i Orsa har RTH växt fram genom hårt arbete, gediget hantverk och ett
              starkt lokalt förtroende. Som familjeföretag är varje uppdrag personligt för oss.
            </p>
            <p>
              Idag hjälper vi allt från villaägare och bostadsrättsföreningar till lantbruk och
              företag med allt inom el – från små servicejobb till kompletta installationer och
              framtidssäkra lösningar som laddboxar och solceller.
            </p>
          </div>
          <p className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-primary">
            <MapPin className="size-4" /> Orsa · Mora · Älvdalen · Hela Dalarna
          </p>
        </div>
      </section>

      <section className="bg-surface py-16">
        <div className="container-px">
          <SectionHeading eyebrow="Värderingar" title="Det vi står för" />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {values.map((v) => (
              <div key={v.title} className="rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)]">
                <div className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary">
                  <v.icon className="size-5" />
                </div>
                <h3 className="mt-4 font-semibold">{v.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="container-px grid gap-6 py-16 md:grid-cols-2">
        <div className="ink-section rounded-3xl p-8">
          <Eye className="size-7 text-primary-glow" />
          <h2 className="mt-4 text-2xl font-bold text-ink-foreground">Vår vision</h2>
          <p className="mt-3 text-ink-foreground/75">
            Att vara Dalarnas mest betrodda elpartner – företaget man rekommenderar till vänner,
            grannar och kollegor, gång på gång.
          </p>
        </div>
        <div className="rounded-3xl border border-border bg-card p-8 shadow-[var(--shadow-card)]">
          <Target className="size-7 text-primary" />
          <h2 className="mt-4 text-2xl font-bold">Vårt löfte</h2>
          <p className="mt-3 text-muted-foreground">
            Tydliga offerter, hållbar kvalitet och ett bemötande som gör skillnad. Vi gör jobbet
            rätt från början – med garanti.
          </p>
          <ul className="mt-5 grid grid-cols-2 gap-3">
            {certs.map((c) => (
              <li key={c} className="flex items-center gap-2 text-sm font-medium">
                <Sparkles className="size-4 text-primary" /> {c}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <Testimonials />
      <CtaBand />
    </>
  );
}
