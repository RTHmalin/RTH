import {
  Zap,
  Search,
  Wrench,
  Hammer,
  Building2,
  Lightbulb,
  PlugZap,
  Home,
  Factory,
  Building,
  type LucideIcon,
} from "lucide-react";

export interface ServiceProcessStep {
  title: string;
  text: string;
}

export interface ServiceFaq {
  q: string;
  a: string;
}

export interface Service {
  slug: string;
  icon: LucideIcon;
  title: string;
  short: string;
  description: string;
  benefits: string[];
  process: ServiceProcessStep[];
  faq: ServiceFaq[];
}

const baseProcess: ServiceProcessStep[] = [
  { title: "Kostnadsfri offert", text: "Vi går igenom dina behov och tar fram ett tydligt fastpris utan dolda kostnader." },
  { title: "Planering", text: "Vi planerar arbetet efter dina önskemål och gällande regler för en säker installation." },
  { title: "Utförande", text: "Certifierade elektriker utför arbetet snabbt, rent och med högsta kvalitet." },
  { title: "Kvalitetskontroll", text: "Vi dokumenterar, testar och garanterar att allt fungerar innan vi lämnar." },
];

export const services: Service[] = [
  {
    slug: "elinstallationer",
    icon: Zap,
    title: "Elinstallationer",
    short: "Trygga elinstallationer för hem, företag och fastigheter.",
    description:
      "Vi utför kompletta elinstallationer för villor, lägenheter, företag och fastigheter i Orsa, Mora, Älvdalen och hela Dalarna. Allt utförs av certifierade elektriker enligt gällande regelverk.",
    benefits: ["Certifierade elektriker", "Fast pris", "Säkra installationer", "Dokumentation & garanti"],
    process: baseProcess,
    faq: [
      { q: "Hur snabbt kan ni komma?", a: "Vi har snabb lokal service i Orsa-, Mora- och Älvdalsområdet och bokar oftast in besök inom några dagar." },
      { q: "Får jag ROT-avdrag?", a: "Ja, för privatpersoner drar vi av ROT-avdraget direkt på fakturan när det är tillämpligt." },
    ],
  },
  {
    slug: "felsokning",
    icon: Search,
    title: "Felsökning",
    short: "Snabb och noggrann felsökning av elsystem.",
    description:
      "Krånglar elen? Vi lokaliserar och åtgärdar fel snabbt och säkert – från utlösta jordfelsbrytare till komplexa fel i elcentralen. Trygg felsökning med modern mätutrustning.",
    benefits: ["Snabb inställelse", "Modern mätutrustning", "Tydlig felrapport", "Säker åtgärd"],
    process: baseProcess,
    faq: [
      { q: "Vad kostar en felsökning?", a: "Vi ger dig ett tydligt timpris och en uppskattning innan vi börjar. Ofta är felet hittat och åtgärdat samma besök." },
    ],
  },
  {
    slug: "elservice",
    icon: Wrench,
    title: "Elservice",
    short: "Löpande elservice och underhåll du kan lita på.",
    description:
      "Allt från byte av strömbrytare och uttag till större serviceuppdrag. Vi hjälper privatpersoner och företag med snabb och pålitlig elservice i hela Dalarna.",
    benefits: ["Lokalt företag", "Flexibla tider", "Erfarna elektriker", "Garanti på arbetet"],
    process: baseProcess,
    faq: [{ q: "Har ni avtal för företag?", a: "Ja, vi erbjuder serviceavtal för företag och fastighetsägare med prioriterad inställelse." }],
  },
  {
    slug: "renovering",
    icon: Hammer,
    title: "Renovering",
    short: "El vid renovering av kök, bad och hela hem.",
    description:
      "Vid renovering ser vi till att elen blir säker, modern och framtidssäker. Vi samarbetar gärna med övriga hantverkare för ett smidigt projekt från start till mål.",
    benefits: ["Helhetslösning", "Framtidssäker el", "Samordning med hantverkare", "ROT-avdrag"],
    process: baseProcess,
    faq: [{ q: "Hjälper ni till med planeringen?", a: "Absolut – vi ger råd om placering av uttag, belysning och smarta lösningar redan i planeringsstadiet." }],
  },
  {
    slug: "nybyggnation",
    icon: Building2,
    title: "Nybyggnation",
    short: "Komplett el för nybyggda hus och fastigheter.",
    description:
      "Vi projekterar och installerar all el i ditt nybygge – från elcentral och kabeldragning till belysning, laddbox och smarta hem-lösningar. Allt enligt senaste standard.",
    benefits: ["Projektering", "Modern standard", "Förberedd för framtiden", "Helhetsansvar"],
    process: baseProcess,
    faq: [{ q: "Kan ni förbereda för laddbox och solceller?", a: "Ja, vi förbereder gärna elcentralen för laddbox, solceller och smarta hem redan vid nybyggnation." }],
  },
  {
    slug: "belysning",
    icon: Lightbulb,
    title: "Belysning",
    short: "Stämningsfull och energismart belysning.",
    description:
      "Rätt belysning förvandlar ett rum. Vi installerar inomhus- och utomhusbelysning, spotlights, LED-lister och smart styrning som sparar energi och skapar rätt känsla.",
    benefits: ["Energismart LED", "Smart styrning", "Inne & ute", "Designrådgivning"],
    process: baseProcess,
    faq: [{ q: "Kan jag styra belysningen via mobilen?", a: "Ja, vi installerar smart belysning som du styr via app, röst eller scenarier." }],
  },
  {
    slug: "laddboxar",
    icon: PlugZap,
    title: "Laddboxar",
    short: "Säker laddbox för elbilen hemma och på företaget.",
    description:
      "Vi installerar laddboxar för villa, BRF och företag. Trygg installation av certifierad elektriker, korrekt avsäkring och hjälp med bidrag och föranmälan.",
    benefits: ["Snabb laddning", "Säker installation", "Hjälp med bidrag", "För villa & företag"],
    process: baseProcess,
    faq: [{ q: "Hjälper ni med Grön Teknik-avdrag?", a: "Ja, vi drar av avdraget för Grön Teknik direkt på fakturan där det är tillämpligt." }],
  },
  {
    slug: "smarta-hem",
    icon: Home,
    title: "Smarta hem",
    short: "Smart styrning av el, ljus, värme och säkerhet.",
    description:
      "Gör ditt hem smartare och tryggare. Vi installerar lösningar för styrning av belysning, värme, larm och energiförbrukning – allt samlat i en app.",
    benefits: ["Energibesparing", "Ökad komfort", "Trygghet & larm", "Allt i en app"],
    process: baseProcess,
    faq: [{ q: "Fungerar det med befintliga produkter?", a: "Vi väljer öppna och kompatibla system som fungerar med de flesta märken och plattformar." }],
  },
  {
    slug: "foretagsservice",
    icon: Factory,
    title: "Företagsservice",
    short: "El och service för företag och industri.",
    description:
      "Vi är din lokala elpartner för företag i Dalarna. Allt från löpande service och felsökning till större installationer och kraftförsörjning – med minimal driftstörning.",
    benefits: ["Serviceavtal", "Prioriterad service", "Industri & verkstad", "Minimal driftstörning"],
    process: baseProcess,
    faq: [{ q: "Erbjuder ni jour?", a: "Vi erbjuder prioriterad akutservice för företagskunder med serviceavtal." }],
  },
  {
    slug: "fastighetsservice",
    icon: Building,
    title: "Fastighetsservice",
    short: "Trygg elservice för fastighetsägare och BRF.",
    description:
      "Vi sköter elen i din fastighet – från allmän belysning och elcentraler till laddboxar och energioptimering. Trygg partner för fastighetsägare och bostadsrättsföreningar.",
    benefits: ["Fastighetsavtal", "Laddinfrastruktur", "Energioptimering", "Trygg dokumentation"],
    process: baseProcess,
    faq: [{ q: "Kan ni installera laddplatser för BRF?", a: "Ja, vi projekterar och installerar laddinfrastruktur för bostadsrättsföreningar och fastigheter." }],
  },
];

export const getService = (slug: string) => services.find((s) => s.slug === slug);
