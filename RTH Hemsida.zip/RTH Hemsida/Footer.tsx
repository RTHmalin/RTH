import { Link } from "@tanstack/react-router";
import { Phone, Mail, MapPin, Clock } from "lucide-react";
import { Logo } from "@/components/Logo";
import { services } from "@/data/services";

export function Footer() {
  return (
    <footer className="ink-section mt-24">
      <div className="container-px grid gap-12 py-16 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="text-ink-foreground">
            <Logo variant="light" />
          </div>
          <p className="mt-4 max-w-xs text-sm text-ink-foreground/70">
            RTH i Orsa AB – din lokala elpartner i Orsa, Mora, Älvdalen och
            hela Dalarna.
          </p>
          <a
            href="tel:025042277"
            className="mt-5 inline-flex items-center gap-2 text-lg font-semibold text-ink-foreground"
          >
            <Phone className="size-5 text-primary-glow" /> 0250-422 77
          </a>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-ink-foreground/60">
            Tjänster
          </h3>
          <ul className="mt-4 space-y-2.5 text-sm">
            {services.slice(0, 6).map((s) => (
              <li key={s.slug}>
                <Link
                  to="/tjanster/$slug"
                  params={{ slug: s.slug }}
                  className="text-ink-foreground/75 transition-colors hover:text-ink-foreground"
                >
                  {s.title}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-ink-foreground/60">
            Genvägar
          </h3>
          <ul className="mt-4 space-y-2.5 text-sm">
            {[
              { to: "/projekt", label: "Projekt" },
              { to: "/om-oss", label: "Om oss" },
              { to: "/kontakt", label: "Kontakt" },
              { to: "/offert", label: "Begär offert" },
            ].map((l) => (
              <li key={l.to}>
                <Link
                  to={l.to}
                  className="text-ink-foreground/75 transition-colors hover:text-ink-foreground"
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-ink-foreground/60">
            Kontakt
          </h3>
          <ul className="mt-4 space-y-3 text-sm text-ink-foreground/75">
            <li className="flex items-start gap-2.5">
              <MapPin className="mt-0.5 size-4 shrink-0 text-primary-glow" /> Klockarvägen 3K, Orsa
            </li>
            <li className="flex items-start gap-2.5">
              <Mail className="mt-0.5 size-4 shrink-0 text-primary-glow" /> info@rthel.se
            </li>
            <li className="flex items-start gap-2.5">
              <Clock className="mt-0.5 size-4 shrink-0 text-primary-glow" /> Mån–Fre 07–16
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-ink-foreground/10">
        <div className="container-px flex flex-col items-center justify-between gap-2 py-6 text-xs text-ink-foreground/55 sm:flex-row">
          <p>© {new Date().getFullYear()} RTH i Orsa AB. Alla rättigheter förbehållna.</p>
          <p>Orsa · Mora · Älvdalen · Hela Dalarna</p>
        </div>
      </div>
    </footer>
  );
}
