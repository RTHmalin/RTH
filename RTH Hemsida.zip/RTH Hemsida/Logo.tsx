import { cn } from "@/lib/utils";

type LogoVariant = "color" | "light" | "mono";

interface LogoProps {
  className?: string;
  variant?: LogoVariant;
  showText?: boolean;
}

/**
 * RTH brand mark — clean "RTH" wordmark.
 */
export function Logo({ className, variant = "color", showText = true }: LogoProps) {
  const graphite =
    variant === "light" ? "currentColor" : variant === "mono" ? "currentColor" : "var(--ink)";
  const blue =
    variant === "mono" ? "currentColor" : variant === "light" ? "currentColor" : "var(--primary)";

  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <svg
        viewBox="0 0 168 64"
        className="h-7 w-auto"
        role="img"
        aria-label="RTH i Orsa AB"
        fill="none"
      >
        <text
          x="0"
          y="48"
          fontFamily="Sora, sans-serif"
          fontWeight="800"
          fontSize="52"
          letterSpacing="-1"
        >
          <tspan fill={graphite}>R</tspan>
          <tspan fill={blue}>T</tspan>
          <tspan fill={graphite}>H</tspan>
        </text>
      </svg>
    </span>
  );
}
