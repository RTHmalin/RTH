export interface Project {
  slug: string;
  title: string;
  category: string;
  location: string;
  excerpt: string;
  challenge: string;
  solution: string;
  result: string;
  image: "electrician" | "laddbox" | "van" | "lighting";
}

export const projectCategories = [
  "Elinstallationer",
  "Företagsprojekt",
  "Laddboxar",
  "Solpaneler",
  "Belysning",
] as const;

export const projects: Project[] = [
  {
    slug: "ny-elcentral-villa-orsa",
    title: "Ny elcentral i villa, Orsa",
    category: "Elinstallationer",
    location: "Orsa",
    excerpt: "Komplett byte av elcentral och säkrare elsystem i äldre villa.",
    challenge: "En äldre villa med utdaterad elcentral och återkommande fel som riskerade säkerheten.",
    solution: "Vi installerade en ny modern elcentral med jordfelsbrytare och dokumenterade hela anläggningen.",
    result: "Tryggare hem, lägre energiförbrukning och en anläggning förberedd för framtidens behov.",
    image: "electrician",
  },
  {
    slug: "laddboxar-brf-mora",
    title: "Laddinfrastruktur för BRF, Mora",
    category: "Laddboxar",
    location: "Mora",
    excerpt: "12 laddplatser med dynamisk lastbalansering för bostadsrättsförening.",
    challenge: "Föreningen ville erbjuda laddplatser utan att överbelasta fastighetens elnät.",
    solution: "Vi installerade laddboxar med dynamisk lastbalansering och individuell mätning per plats.",
    result: "Smidig elbilsladdning för medlemmarna och full kontroll på förbrukningen.",
    image: "laddbox",
  },
  {
    slug: "belysning-restaurang-alvdalen",
    title: "Belysningsprojekt restaurang, Älvdalen",
    category: "Belysning",
    location: "Älvdalen",
    excerpt: "Stämningsfull och energismart LED-belysning med smart styrning.",
    challenge: "Restaurangen ville skapa rätt atmosfär samtidigt som energikostnaden hölls nere.",
    solution: "Vi designade en belysningslösning med dimbar LED och scenstyrning för olika tider på dygnet.",
    result: "En inbjudande miljö för gästerna och kraftigt sänkta energikostnader.",
    image: "lighting",
  },
  {
    slug: "solceller-lantbruk-dalarna",
    title: "Solcellsanläggning lantbruk, Dalarna",
    category: "Solpaneler",
    location: "Dalarna",
    excerpt: "Stor takmonterad solcellsanläggning för lantbruksfastighet.",
    challenge: "Lantbruket hade hög elförbrukning och ville bli mer självförsörjande på el.",
    solution: "Vi projekterade och installerade en takmonterad solcellsanläggning med optimerare.",
    result: "Betydligt lägre elkostnad och en grönare, mer hållbar verksamhet.",
    image: "van",
  },
  {
    slug: "elinstallation-nybygge-orsa",
    title: "El i nybyggd villa, Orsa",
    category: "Elinstallationer",
    location: "Orsa",
    excerpt: "Komplett elinstallation förberedd för smart hem och laddbox.",
    challenge: "Husägaren ville ha ett framtidssäkert hem med smart styrning från start.",
    solution: "Vi installerade all el inklusive smart hem-system, laddboxförberedelse och designbelysning.",
    result: "Ett modernt, smart och energieffektivt hem klart för inflyttning.",
    image: "electrician",
  },
  {
    slug: "foretagsservice-verkstad-mora",
    title: "Elservice verkstad, Mora",
    category: "Företagsprojekt",
    location: "Mora",
    excerpt: "Uppgradering av kraftförsörjning och belysning i industrilokal.",
    challenge: "Verkstaden behövde mer kapacitet för nya maskiner utan långa driftstopp.",
    solution: "Vi uppgraderade kraftförsörjningen och bytte till energieffektiv LED-belysning utanför produktionstid.",
    result: "Stabil drift, bättre arbetsmiljö och lägre driftskostnader.",
    image: "van",
  },
];

export const getProject = (slug: string) => projects.find((p) => p.slug === slug);

export interface Testimonial {
  name: string;
  location: string;
  rating: number;
  text: string;
}

export const testimonials: Testimonial[] = [
  {
    name: "Anna Bergström",
    location: "Orsa",
    rating: 5,
    text: "Otroligt proffsigt bemötande och snabb service. Vår nya elcentral installerades perfekt och allt dokumenterades. Rekommenderas varmt!",
  },
  {
    name: "Johan Eriksson",
    location: "Mora",
    rating: 5,
    text: "Installerade laddbox till elbilen. Tydlig offert, prick i tid och hjälpte oss med bidraget. Lokalt företag man kan lita på.",
  },
  {
    name: "Maria Lindqvist",
    location: "Älvdalen",
    rating: 5,
    text: "Vi anlitade RTH för belysningen i vårt nya kök. Resultatet blev fantastiskt och de gav massor av bra råd på vägen.",
  },
  {
    name: "Per Nordin",
    location: "Orsa",
    rating: 5,
    text: "Snabb felsökning när jordfelsbrytaren krånglade. Hittade felet direkt och fixade det samma dag. Mycket nöjd!",
  },
];
