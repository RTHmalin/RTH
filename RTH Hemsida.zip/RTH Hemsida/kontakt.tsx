import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Phone, Mail, MapPin, Clock, Send, AlertCircle } from "lucide-react";
import { PageHero } from "@/components/site/PageHero";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export const Route = createFileRoute("/kontakt")({
  head: () => ({
    meta: [
      { title: "Kontakt | RTH i Orsa AB – Elektriker Orsa 0250-422 77" },
      {
        name: "description",
        content:
          "Kontakta RTH i Orsa AB i Orsa. Ring 0250-422 77 eller skicka en förfrågan. Vi hjälper dig i Orsa, Mora och hela Dalarna.",
      },
      { property: "og:title", content: "Kontakta RTH | Elektriker i Dalarna" },
      { property: "og:description", content: "Ring 0250-422 77 eller skicka ett meddelande." },
    ],
  }),
  component: ContactPage,
});

const contactInfo = [
  { icon: Phone, label: "Telefon", value: "0250-422 77", href: "tel:025042277" },
  { icon: Mail, label: "E-post", value: "info@rthel.se", href: "mailto:info@rthel.se" },
  { icon: MapPin, label: "Adress", value: "Klockarvägen 3K, Orsa" },
  { icon: Clock, label: "Öppettider", value: "Mån–Fre 07:00–16:00" },
];

function ContactPage() {
  const [sent, setSent] = useState(false);

  return (
    <>
      <PageHero
        eyebrow="Kontakt"
        title="Hör av dig till oss"
        description="Vi svarar gärna på dina frågor och hjälper dig snabbt. Ring oss eller skicka ett meddelande nedan."
      />

      <section className="container-px grid gap-10 py-14 lg:grid-cols-[1fr_1.1fr]">
        {/* Info + akut */}
        <div>
          <div className="grid gap-4 sm:grid-cols-2">
            {contactInfo.map((c) => (
              <div key={c.label} className="rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-card)]">
                <div className="grid size-10 place-items-center rounded-lg bg-primary/10 text-primary">
                  <c.icon className="size-5" />
                </div>
                <p className="mt-3 text-xs uppercase tracking-wide text-muted-foreground">{c.label}</p>
                {c.href ? (
                  <a href={c.href} className="font-semibold hover:text-primary">{c.value}</a>
                ) : (
                  <p className="font-semibold">{c.value}</p>
                )}
              </div>
            ))}
          </div>

          <div className="mt-4 flex items-start gap-3 rounded-2xl border border-primary/30 bg-accent p-5">
            <AlertCircle className="mt-0.5 size-5 shrink-0 text-primary" />
            <div>
              <p className="font-semibold text-accent-foreground">Akutservice</p>
              <p className="text-sm text-accent-foreground/80">
                Vid akuta elproblem – ring oss direkt på{" "}
                <a href="tel:025042277" className="font-semibold underline">0250-422 77</a>.
              </p>
            </div>
          </div>

          <div className="mt-4 overflow-hidden rounded-2xl border border-border shadow-[var(--shadow-card)]">
            <iframe
              title="Karta över Orsa, Dalarna"
              src="https://www.openstreetmap.org/export/embed.html?bbox=14.55%2C61.08%2C14.70%2C61.16&layer=mapnik&marker=61.12%2C14.61"
              className="h-64 w-full"
              loading="lazy"
            />
          </div>
        </div>

        {/* Form */}
        <div className="rounded-3xl border border-border bg-card p-6 shadow-[var(--shadow-card)] sm:p-8">
          <h2 className="text-xl font-bold">Skicka ett meddelande</h2>
          {sent ? (
            <div className="mt-6 rounded-2xl bg-success/10 p-6 text-center">
              <p className="font-semibold text-success">Tack för ditt meddelande!</p>
              <p className="mt-1 text-sm text-muted-foreground">Vi återkommer så snart vi kan.</p>
            </div>
          ) : (
            <form
              className="mt-6 space-y-4"
              onSubmit={async (e) => {
                e.preventDefault();
                const data = new FormData(e.currentTarget);
                const { supabase } = await import("@/integrations/supabase/client");
                const { error } = await supabase.from("leads").insert({
                  kind: "kontakt",
                  name: String(data.get("name") || ""),
                  phone: String(data.get("phone") || ""),
                  email: String(data.get("email") || ""),
                  message: String(data.get("message") || ""),
                });
                if (error) {
                  toast.error("Något gick fel. Ring oss på 0250-422 77.");
                  return;
                }
                setSent(true);
                toast.success("Ditt meddelande har skickats!");
              }}
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="name">Namn</Label>
                  <Input id="name" name="name" required placeholder="Ditt namn" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="phone">Telefon</Label>
                  <Input id="phone" name="phone" type="tel" required placeholder="070-123 45 67" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="email">E-post</Label>
                <Input id="email" name="email" type="email" required placeholder="din@epost.se" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="message">Meddelande</Label>
                <Textarea id="message" name="message" required rows={5} placeholder="Beskriv vad du behöver hjälp med..." />
              </div>
              <Button type="submit" variant="hero" size="lg" className="w-full">
                <Send className="size-4" /> Skicka meddelande
              </Button>
            </form>
          )}
        </div>
      </section>
    </>
  );
}
