import { createFileRoute, Link, notFound, useRouter } from "@tanstack/react-router";
import { ArrowRight, Check, Phone } from "lucide-react";
import { getService, services } from "@/data/services";
import { Button } from "@/components/ui/button";
import { PageHero } from "@/components/site/PageHero";
import { SectionHeading } from "@/components/site/SectionHeading";
import { Testimonials } from "@/components/site/Testimonials";
import { CtaBand } from "@/components/site/CtaBand";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/tjanster/$slug")({
  loader: ({ params }) => {
    const service = getService(params.slug);
    if (!service) throw notFound();
    return { slug: service.slug };
  },
  head: ({ params }) => {
    const s = getService(params.slug);
    return {
      meta: [
        { title: s ? `${s.title} i Orsa, Mora & Dalarna | RTH` : "Tjänst | RTH" },
        { name: "description", content: s?.short ?? "" },
        { property: "og:title", content: s ? `${s.title} | RTH i Orsa AB` : "RTH" },
        { property: "og:description", content: s?.description ?? "" },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="container-px py-24 text-center">
      <h1 className="text-2xl font-bold">Tjänsten hittades inte</h1>
      <Button asChild variant="hero" className="mt-6">
        <Link to="/tjanster">Se alla tjänster</Link>
      </Button>
    </div>
  ),
  errorComponent: ErrorView,
  component: ServiceDetail,
});

function ErrorView({ reset }: { error: Error; reset: () => void }) {
  const router = useRouter();
  return (
    <div className="container-px py-24 text-center">
      <h1 className="text-2xl font-bold">Något gick fel</h1>
      <Button
        className="mt-6"
        onClick={() => {
          router.invalidate();
          reset();
        }}
      >
        Försök igen
      </Button>
    </div>
  );
}

function ServiceDetail() {
  const { slug } = Route.useLoaderData();
  const service = getService(slug)!;
  const related = services.filter((s) => s.slug !== service.slug).slice(0, 3);
  const Icon = service.icon;

  return (
    <>
      <PageHero eyebrow="Tjänst" title={service.title} description={service.description}>
        <div className="flex flex-col gap-3 sm:flex-row">
          <Button asChild variant="hero" size="lg">
            <Link to="/offert">
              Begär offert <ArrowRight className="size-4" />
            </Link>
          </Button>
          <Button asChild variant="onInk" size="lg">
            <a href="tel:025042277">
              <Phone className="size-4" /> 0250-422 77
            </a>
          </Button>
        </div>
      </PageHero>

      {/* Benefits */}
      <section className="container-px py-16">
        <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
          <div className="rounded-2xl border border-border bg-card p-8 shadow-[var(--shadow-card)]">
            <div className="grid size-12 place-items-center rounded-xl bg-primary/10 text-primary">
              <Icon className="size-6" />
            </div>
            <h2 className="mt-5 text-2xl font-bold">Varför välja RTH för {service.title.toLowerCase()}?</h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              {service.benefits.map((b: string) => (
                <div key={b} className="flex items-start gap-3">
                  <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-success/15 text-success">
                    <Check className="size-4" />
                  </span>
                  <span className="text-sm font-medium">{b}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="ink-section flex flex-col justify-center rounded-2xl p-8">
            <p className="text-sm uppercase tracking-wider text-ink-foreground/60">Lokal elpartner</p>
            <p className="mt-3 text-2xl font-bold text-ink-foreground">
              Vi finns i Orsa, Mora &amp; Älvdalen
            </p>
            <p className="mt-3 text-sm text-ink-foreground/70">
              Snabb inställelse och personlig service i hela Dalarna.
            </p>
            <Button asChild variant="hero" size="lg" className="mt-6 self-start">
              <Link to="/kontakt">Kontakta oss</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="bg-surface py-16">
        <div className="container-px">
          <SectionHeading eyebrow="Så går det till" title="Vår arbetsprocess" />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {service.process.map((step: { title: string; text: string }, i: number) => (
              <div
                key={step.title}
                className="relative rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)]"
              >
                <span className="text-3xl font-bold text-primary/30">0{i + 1}</span>
                <h3 className="mt-2 font-semibold">{step.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="container-px py-16">
        <SectionHeading eyebrow="FAQ" title="Vanliga frågor" />
        <Accordion type="single" collapsible className="mx-auto mt-8 max-w-3xl">
          {service.faq.map((f: { q: string; a: string }, i: number) => (
            <AccordionItem key={i} value={`faq-${i}`}>
              <AccordionTrigger className="text-left text-base font-semibold">{f.q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>

      {/* Related */}
      <section className="container-px pb-8">
        <SectionHeading eyebrow="Fler tjänster" title="Upptäck mer" align="left" />
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {related.map((s) => {
            const RIcon = s.icon;
            return (
              <Link
                key={s.slug}
                to="/tjanster/$slug"
                params={{ slug: s.slug }}
                className="group flex items-center gap-4 rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-card)] transition-all hover:-translate-y-0.5 hover:border-primary/40"
              >
                <div className="grid size-11 shrink-0 place-items-center rounded-xl bg-accent text-accent-foreground group-hover:bg-primary group-hover:text-primary-foreground">
                  <RIcon className="size-5" />
                </div>
                <div>
                  <p className="font-semibold">{s.title}</p>
                  <p className="text-sm text-muted-foreground">{s.short}</p>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      <Testimonials />
      <CtaBand title={`Behöver du hjälp med ${service.title.toLowerCase()}?`} />
    </>
  );
}
