import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { User, Building2, Home, Tractor, Check, Upload, Send, ShieldCheck, Clock, BadgePercent } from "lucide-react";
import { PageHero } from "@/components/site/PageHero";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/offert")({
  head: () => ({
    meta: [
      { title: "Begär kostnadsfri offert | RTH i Orsa AB Dalarna" },
      {
        name: "description",
        content:
          "Begär en kostnadsfri och förutsättningslös offert för elinstallation, laddbox, solpanel eller belysning i Orsa, Mora och hela Dalarna.",
      },
      { property: "og:title", content: "Begär kostnadsfri offert | RTH" },
      { property: "og:description", content: "Kostnadsfri offert av certifierad elektriker." },
    ],
  }),
  component: QuotePage,
});

const customerTypes = [
  { id: "privat", label: "Privatperson", icon: User },
  { id: "foretag", label: "Företag", icon: Building2 },
  { id: "brf", label: "BRF", icon: Home },
  { id: "lantbruk", label: "Lantbruk", icon: Tractor },
];

const serviceTypes = ["Elinstallation", "Felsökning", "Laddbox", "Solpanel", "Belysning"];

const perks = [
  { icon: BadgePercent, text: "Helt kostnadsfri offert" },
  { icon: Clock, text: "Svar inom 24 timmar" },
  { icon: ShieldCheck, text: "Certifierade elektriker" },
];

function QuotePage() {
  const [customer, setCustomer] = useState("privat");
  const [service, setService] = useState("Elinstallation");
  const [fileName, setFileName] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  if (sent) {
    return (
      <>
        <PageHero eyebrow="Offert" title="Tack för din förfrågan!" />
        <div className="container-px py-16">
          <div className="mx-auto max-w-lg rounded-3xl border border-border bg-card p-10 text-center shadow-[var(--shadow-card)]">
            <div className="mx-auto grid size-14 place-items-center rounded-full bg-success/15 text-success">
              <Check className="size-7" />
            </div>
            <h2 className="mt-5 text-2xl font-bold">Vi har tagit emot din offertförfrågan</h2>
            <p className="mt-3 text-muted-foreground">
              En av våra elektriker återkommer till dig inom kort. Vid brådskande ärenden, ring{" "}
              <a href="tel:025042277" className="font-semibold text-primary">0250-422 77</a>.
            </p>
            <Button variant="hero" size="lg" className="mt-6" onClick={() => setSent(false)}>
              Skicka en till förfrågan
            </Button>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <PageHero
        eyebrow="Offert"
        title="Begär kostnadsfri offert"
        description="Berätta vad du behöver hjälp med så återkommer vi med ett tydligt förslag – helt utan kostnad och förpliktelser."
      >
        <div className="flex flex-wrap gap-4">
          {perks.map((p) => (
            <span key={p.text} className="inline-flex items-center gap-2 text-sm text-ink-foreground/85">
              <p.icon className="size-4 text-primary-glow" /> {p.text}
            </span>
          ))}
        </div>
      </PageHero>

      <section className="container-px py-14">
        <form
          className="mx-auto max-w-3xl rounded-3xl border border-border bg-card p-6 shadow-[var(--shadow-card)] sm:p-10"
          onSubmit={async (e) => {
            e.preventDefault();
            const form = e.currentTarget;
            const data = new FormData(form);
            const { supabase } = await import("@/integrations/supabase/client");
            const { error } = await supabase.from("leads").insert({
              kind: "offert",
              customer_type: customer,
              service,
              name: String(data.get("name") || ""),
              phone: String(data.get("phone") || ""),
              email: String(data.get("email") || ""),
              address: String(data.get("address") || ""),
              message: String(data.get("message") || ""),
            });
            if (error) {
              toast.error("Något gick fel. Ring oss på 0250-422 77.");
              return;
            }
            setSent(true);
            toast.success("Din offertförfrågan har skickats!");
          }}
        >
          {/* Customer type */}
          <fieldset>
            <legend className="text-sm font-semibold">Jag är</legend>
            <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {customerTypes.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setCustomer(c.id)}
                  className={cn(
                    "flex flex-col items-center gap-2 rounded-xl border p-4 text-sm font-medium transition-all",
                    customer === c.id
                      ? "border-primary bg-accent text-accent-foreground shadow-sm"
                      : "border-border hover:border-primary/40",
                  )}
                >
                  <c.icon className={cn("size-6", customer === c.id ? "text-primary" : "text-muted-foreground")} />
                  {c.label}
                </button>
              ))}
            </div>
          </fieldset>

          {/* Service type */}
          <fieldset className="mt-8">
            <legend className="text-sm font-semibold">Tjänst</legend>
            <div className="mt-3 flex flex-wrap gap-2">
              {serviceTypes.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setService(s)}
                  className={cn(
                    "rounded-full border px-4 py-2 text-sm font-medium transition-colors",
                    service === s
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border hover:border-primary/40",
                  )}
                >
                  {s}
                </button>
              ))}
            </div>
          </fieldset>

          {/* Fields */}
          <div className="mt-8 grid gap-5 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="q-name">Namn</Label>
              <Input id="q-name" name="name" required placeholder="För- och efternamn" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="q-phone">Telefon</Label>
              <Input id="q-phone" name="phone" type="tel" required placeholder="070-123 45 67" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="q-email">E-post</Label>
              <Input id="q-email" name="email" type="email" required placeholder="din@epost.se" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="q-address">Adress</Label>
              <Input id="q-address" name="address" required placeholder="Gata, ort" />
            </div>
          </div>

          <div className="mt-5 space-y-1.5">
            <Label htmlFor="q-message">Meddelande</Label>
            <Textarea id="q-message" name="message" rows={5} required placeholder="Beskriv ditt projekt så detaljerat du kan..." />
          </div>

          {/* Upload */}
          <div className="mt-5">
            <Label htmlFor="q-file">Bilduppladdning (valfritt)</Label>
            <label
              htmlFor="q-file"
              className="mt-1.5 flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-input bg-surface px-4 py-6 text-sm text-muted-foreground transition-colors hover:border-primary/50 hover:text-foreground"
            >
              <Upload className="size-5" />
              {fileName ?? "Klicka för att ladda upp bilder"}
            </label>
            <input
              id="q-file"
              type="file"
              accept="image/*"
              multiple
              className="sr-only"
              onChange={(e) => setFileName(e.target.files?.length ? `${e.target.files.length} fil(er) valda` : null)}
            />
          </div>

          <Button type="submit" variant="hero" size="xl" className="mt-8 w-full">
            <Send className="size-5" /> Begär kostnadsfri offert
          </Button>
          <p className="mt-3 text-center text-xs text-muted-foreground">
            Genom att skicka godkänner du att vi kontaktar dig angående din förfrågan.
          </p>
        </form>
      </section>
    </>
  );
}
