import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/site/PageHero";
import { ServiceCard } from "@/components/site/ServiceCard";
import { Testimonials } from "@/components/site/Testimonials";
import { CtaBand } from "@/components/site/CtaBand";
import { services } from "@/data/services";

export const Route = createFileRoute("/tjanster/")({
  head: () => ({
    meta: [
      { title: "Tjänster | Elinstallation, laddbox & belysning – RTH Dalarna" },
      {
        name: "description",
        content:
          "Våra eltjänster i Orsa, Mora och hela Dalarna: elinstallationer, felsökning, elservice, belysning, laddboxar, smarta hem och företagsservice.",
      },
      { property: "og:title", content: "Våra eltjänster | RTH i Orsa AB" },
      { property: "og:description", content: "Allt inom el för hem och företag i Dalarna." },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="Våra tjänster"
        title="Eltjänster för hem och företag"
        description="Vi erbjuder ett komplett utbud av eltjänster – alltid utfört av certifierade elektriker med trygghet, garanti och lokal närvaro i hela Dalarna."
      />
      <section className="container-px py-16">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s) => (
            <ServiceCard key={s.slug} service={s} />
          ))}
        </div>
      </section>
      <Testimonials />
      <CtaBand />
    </>
  );
}
