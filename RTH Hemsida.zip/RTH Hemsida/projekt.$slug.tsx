import { useState } from "react";
import { createFileRoute, Link, notFound, useRouter } from "@tanstack/react-router";
import { ArrowLeft, MapPin, AlertTriangle, Lightbulb, CheckCircle2, X } from "lucide-react";
import { getProject, projects, type Project } from "@/data/projects";
import { projectImages } from "@/lib/project-images";
import { Button } from "@/components/ui/button";
import { CtaBand } from "@/components/site/CtaBand";

export const Route = createFileRoute("/projekt/$slug")({
  loader: ({ params }) => {
    const project = getProject(params.slug);
    if (!project) throw notFound();
    return { project };
  },
  head: ({ loaderData }) => {
    const p = loaderData?.project;
    return {
      meta: [
        { title: p ? `${p.title} | RTH Projekt` : "Projekt | RTH" },
        { name: "description", content: p?.excerpt ?? "" },
        { property: "og:title", content: p?.title ?? "RTH Projekt" },
        { property: "og:description", content: p?.excerpt ?? "" },
        ...(p ? [{ property: "og:image", content: projectImages[p.image] }] : []),
      ],
    };
  },
  notFoundComponent: () => (
    <div className="container-px py-24 text-center">
      <h1 className="text-2xl font-bold">Projektet hittades inte</h1>
      <Button asChild variant="hero" className="mt-6">
        <Link to="/projekt">Se alla projekt</Link>
      </Button>
    </div>
  ),
  errorComponent: ({ reset }) => {
    const router = useRouter();
    return (
      <div className="container-px py-24 text-center">
        <h1 className="text-2xl font-bold">Något gick fel</h1>
        <Button className="mt-6" onClick={() => { router.invalidate(); reset(); }}>Försök igen</Button>
      </div>
    );
  },
  component: ProjectDetail,
});

function ProjectDetail() {
  const { project } = Route.useLoaderData() as { project: Project };
  const [lightbox, setLightbox] = useState(false);
  const main = projectImages[project.image];
  const gallery = [main, projectImages.lighting, projectImages.laddbox, projectImages.electrician].filter(
    (v, i, arr) => arr.indexOf(v) === i,
  );

  const blocks = [
    { icon: AlertTriangle, title: "Utmaning", text: project.challenge, tone: "text-destructive" },
    { icon: Lightbulb, title: "Lösning", text: project.solution, tone: "text-primary" },
    { icon: CheckCircle2, title: "Resultat", text: project.result, tone: "text-success" },
  ];

  return (
    <div className="container-px py-10">
      <Link to="/projekt" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" /> Tillbaka till projekt
      </Link>

      <div className="mt-6 max-w-3xl">
        <span className="eyebrow justify-start">{project.category}</span>
        <h1 className="mt-3 text-3xl font-bold sm:text-4xl">{project.title}</h1>
        <p className="mt-3 flex items-center gap-1.5 text-muted-foreground">
          <MapPin className="size-4" /> {project.location}
        </p>
        <p className="mt-4 text-lg text-muted-foreground">{project.excerpt}</p>
      </div>

      <button
        onClick={() => setLightbox(true)}
        className="mt-8 block w-full overflow-hidden rounded-3xl shadow-[var(--shadow-elevated)]"
        aria-label="Öppna stor bild"
      >
        <img src={main} alt={project.title} width={1600} height={1100} className="aspect-[16/9] w-full object-cover" />
      </button>

      <div className="mt-4 grid grid-cols-3 gap-3 sm:gap-4">
        {gallery.slice(0, 3).map((img, i) => (
          <button
            key={i}
            onClick={() => setLightbox(true)}
            className="overflow-hidden rounded-2xl"
            aria-label={`Bild ${i + 1}`}
          >
            <img src={img} alt={`${project.title} bild ${i + 1}`} width={600} height={450} loading="lazy" className="aspect-[4/3] w-full object-cover transition-transform duration-500 hover:scale-105" />
          </button>
        ))}
      </div>

      <div className="mt-12 grid gap-6 lg:grid-cols-3">
        {blocks.map((b) => (
          <div key={b.title} className="rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)]">
            <b.icon className={`size-6 ${b.tone}`} />
            <h2 className="mt-3 text-lg font-bold">{b.title}</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{b.text}</p>
          </div>
        ))}
      </div>

      <section className="mt-16">
        <h2 className="text-xl font-bold">Fler projekt</h2>
        <div className="mt-6 grid gap-6 sm:grid-cols-3">
          {projects.filter((p) => p.slug !== project.slug).slice(0, 3).map((p) => (
            <Link key={p.slug} to="/projekt/$slug" params={{ slug: p.slug }} className="group overflow-hidden rounded-2xl border border-border bg-card shadow-[var(--shadow-card)] transition-all hover:-translate-y-1">
              <img src={projectImages[p.image]} alt={p.title} width={600} height={450} loading="lazy" className="aspect-[4/3] w-full object-cover transition-transform duration-500 group-hover:scale-105" />
              <div className="p-4">
                <p className="text-xs text-muted-foreground">{p.location}</p>
                <h3 className="mt-1 font-semibold">{p.title}</h3>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <div className="-mx-5 sm:-mx-8">
        <CtaBand />
      </div>

      {lightbox && (
        <div
          className="fixed inset-0 z-[60] grid place-items-center bg-ink/90 p-4 backdrop-blur"
          onClick={() => setLightbox(false)}
          role="dialog"
          aria-modal="true"
        >
          <button className="absolute right-5 top-5 grid size-11 place-items-center rounded-full bg-background/10 text-ink-foreground hover:bg-background/20" aria-label="Stäng">
            <X className="size-6" />
          </button>
          <img src={main} alt={project.title} className="max-h-[85vh] w-auto max-w-full rounded-2xl object-contain" />
        </div>
      )}
    </div>
  );
}
