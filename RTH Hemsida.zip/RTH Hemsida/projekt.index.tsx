import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, MapPin } from "lucide-react";
import { PageHero } from "@/components/site/PageHero";
import { CtaBand } from "@/components/site/CtaBand";
import { projects, projectCategories } from "@/data/projects";
import { projectImages } from "@/lib/project-images";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/projekt/")({
  head: () => ({
    meta: [
      { title: "Projekt & referenser | RTH i Orsa AB Dalarna" },
      {
        name: "description",
        content:
          "Se våra genomförda elprojekt i Orsa, Mora och Dalarna – elinstallationer, laddboxar, solceller och belysning för hem och företag.",
      },
      { property: "og:title", content: "Våra projekt | RTH" },
      { property: "og:description", content: "Referensprojekt inom el i Dalarna." },
    ],
  }),
  component: ProjectsPage,
});

function ProjectsPage() {
  const [category, setCategory] = useState<string>("Alla");
  const filtered = category === "Alla" ? projects : projects.filter((p) => p.category === category);

  return (
    <>
      <PageHero
        eyebrow="Projekt"
        title="Referensprojekt i Dalarna"
        description="Ett urval av elprojekt vi genomfört för privatpersoner och företag. Kvalitet, säkerhet och nöjda kunder."
      />

      <section className="container-px py-12">
        <div className="flex flex-wrap gap-2">
          {["Alla", ...projectCategories].map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={cn(
                "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
                category === c
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card hover:border-primary/40",
              )}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => (
            <Link
              key={p.slug}
              to="/projekt/$slug"
              params={{ slug: p.slug }}
              className="group overflow-hidden rounded-2xl border border-border bg-card shadow-[var(--shadow-card)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[var(--shadow-elevated)]"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={projectImages[p.image]}
                  alt={p.title}
                  width={1200}
                  height={900}
                  loading="lazy"
                  className="size-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <span className="absolute left-3 top-3 rounded-full bg-background/90 px-3 py-1 text-xs font-semibold backdrop-blur">
                  {p.category}
                </span>
              </div>
              <div className="p-5">
                <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <MapPin className="size-3.5" /> {p.location}
                </p>
                <h3 className="mt-1.5 font-semibold">{p.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{p.excerpt}</p>
                <span className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-primary">
                  Se projekt <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <CtaBand />
    </>
  );
}
