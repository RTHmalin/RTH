import electrician from "@/assets/hero-electrician.jpg";
import laddbox from "@/assets/service-laddbox.jpg";
import van from "@/assets/service-van.jpg";
import lighting from "@/assets/service-lighting.jpg";
import type { Project } from "@/data/projects";

export const projectImages: Record<Project["image"], string> = {
  electrician,
  laddbox,
  van,
  lighting,
};
