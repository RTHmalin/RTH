import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Phone,
  ArrowRight,
  ShieldCheck,
  Clock3,
  MapPin,
  PlugZap,
  Award,
  Star,
} from "lucide-react";
import heroImg from "@/assets/hero-electrician.jpg";
import laddboxImg from "@/assets/service-laddbox.jpg";
import lightingImg from "@/assets/service-lighting.jpg";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/site/SectionHeading";
import { ServiceCard } from "@/components/site/ServiceCard";
import { Testimonials } from "@/components/site/Testimonials";
import { CtaBand } from "@/components/site/CtaBand";
import { services } from "@/data/services";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Elektriker i Orsa, Mora & Dalarna | RTH i Orsa AB" },
      {
        name: "description",
        content:
          "Säkra elinstallationer för hem och företag i Orsa, Mora, Älvdalen och hela Dalarna. Elinstallation, felsökning, belysning, laddboxar och elservice. Ring 0250-422 77.",
      },
      { property: "og:title", content: "RTH i Orsa AB" },
      {
        property: "og:description",
        content: "Säkra elinstallationer för hem och företag i Orsa, Mora och hela Dalarna.",
      },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Electrician",
          name: "RTH i Orsa AB",
          telephone: "+46250-42277",
          areaServed: ["Orsa", "Mora", "Älvdalen", "Dalarna"],
          address: { "@type": "PostalAddress", addressLocality: "Orsa", addressRegion: "Dalarna", addressCountry: "SE" },
          aggregateRating: { "@type": "AggregateRating", ratingValue: "5", reviewCount: "120" },
        }),
      },
    ],
  }),
  component: HomePage,
});

const benefits = [
  { icon: Award, title: "Certifierade elektriker", text: "Behörig personal och dokumenterat arbete." },
  { icon: Clock3, title: "Snabb service", text: "Lokal närvaro ger snabb inställelse." },
  { icon: MapPin, title: "Lokalt företag", text: "Vi finns mitt i Dalarna – nära dig." },
  { icon: ShieldCheck, title: "Säker installation", text: "Allt utförs enligt gällande regelverk." },
  { icon: Star, title: "Garanti", text: "Vi står för kvaliteten på vårt arbete." },
];

function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative isolate overflow-hidden ink-section">
        <img
          src={heroImg}
          alt="Certifierad elektriker installerar elcentral"
          width={1600}
          height={1100}
          className="absolute inset-0 size-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-[linear-gradient(110deg,oklch(0.18_0.02_252/0.92)_30%,oklch(0.2_0.03_252/0.55)_100%)]" />
        <div className="container-px relative grid min-h-[88vh] items-center py-20">
          <div className="max-w-2xl">
            <p className="eyebrow justify-start text-primary-glow">
              <PlugZap className="size-4" /> Orsa · Mora · Älvdalen · Hela Dalarna
            </p>
            <h1 className="mt-5 text-4xl font-bold leading-[1.05] text-ink-foreground sm:text-5xl lg:text-6xl">
              Säkra elinstallationer för hem och företag
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-foreground/80">
              RTH hjälper privatpersoner och företag med elinstallationer, felsökning, belysning,
              laddboxar och service i Orsa, Mora och hela Dalarna.
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
              <Button asChild variant="hero" size="xl">
                <a href="tel:025042277">
                  <Phone className="size-5" /> Ring nu
                </a>
              </Button>
              <Button asChild variant="onInk" size="xl">
                <Link to="/offert">
                  Begär offert <ArrowRight className="size-5" />
                </Link>
              </Button>
            </div>
            <dl className="mt-12 flex flex-wrap gap-x-10 gap-y-4">
              {[
                { k: "20+", v: "års erfarenhet" },
                { k: "100%", v: "certifierat arbete" },
                { k: "5.0", v: "kundbetyg" },
              ].map((s) => (
                <div key={s.v}>
                  <dt className="text-3xl font-bold text-ink-foreground">{s.k}</dt>
                  <dd className="text-sm text-ink-foreground/65">{s.v}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>

      {/* BENEFITS */}
      <section className="border-b border-border bg-surface py-14">
        <div className="container-px grid grid-cols-2 gap-6 md:grid-cols-3 lg:grid-cols-5">
          {benefits.map((b) => (
            <div key={b.title} className="flex flex-col items-start gap-3">
              <div className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary">
                <b.icon className="size-5" />
              </div>
              <div>
                <p className="font-semibold leading-tight">{b.title}</p>
                <p className="mt-1 text-sm text-muted-foreground">{b.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES */}
      <section className="py-20">
        <div className="container-px">
          <SectionHeading
            eyebrow="Våra tjänster"
            title="El för hela ditt behov"
            description="Från enkel elservice till kompletta installationer – vi löser det tryggt och professionellt."
          />
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {services.map((s) => (
              <ServiceCard key={s.slug} service={s} />
            ))}
          </div>
          <div className="mt-10 text-center">
            <Button asChild variant="outline" size="lg">
              <Link to="/tjanster">
                Se alla tjänster <ArrowRight className="size-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* FEATURE SPLIT */}
      <section className="container-px grid items-center gap-10 py-12 lg:grid-cols-2">
        <div className="overflow-hidden rounded-3xl shadow-[var(--shadow-elevated)]">
          <img
            src={laddboxImg}
            alt="Installation av laddbox för elbil"
            width={1200}
            height={900}
            loading="lazy"
            className="h-full w-full object-cover"
          />
        </div>
        <div>
          <SectionHeading
            align="left"
            eyebrow="Laddboxar & grön teknik"
            title="Ladda elbilen tryggt hemma"
            description="Vi installerar laddboxar för villa, BRF och företag – med korrekt avsäkring, dynamisk lastbalansering och hjälp med avdrag för grön teknik."
          />
          <ul className="mt-6 space-y-3">
            {["Certifierad installation", "Hjälp med bidrag & föranmälan", "För villa, BRF & företag"].map(
              (li) => (
                <li key={li} className="flex items-center gap-3 text-sm">
                  <ShieldCheck className="size-5 text-primary" /> {li}
                </li>
              ),
            )}
          </ul>
          <Button asChild variant="hero" size="lg" className="mt-8">
            <Link to="/tjanster/$slug" params={{ slug: "laddboxar" }}>
              Läs om laddboxar <ArrowRight className="size-4" />
            </Link>
          </Button>
        </div>
      </section>



      <Testimonials />
      <CtaBand />

      {/* image used to keep visual richness in lighting context */}
      <span className="hidden">{lightingImg}</span>
    </>
  );
}
