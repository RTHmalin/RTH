import { Link } from "@tanstack/react-router";
import { Phone, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export function CtaBand({
  title = "Redo att starta ditt elprojekt?",
  text = "Få en kostnadsfri offert av en certifierad elektriker. Vi hjälper dig i Orsa, Mora, Älvdalen och hela Dalarna.",
}: {
  title?: string;
  text?: string;
}) {
  return (
    <section className="container-px py-20">
      <div className="ink-section relative overflow-hidden rounded-3xl px-6 py-14 text-center shadow-[var(--shadow-elevated)] sm:px-12 sm:py-16">
        <div className="pointer-events-none absolute -right-16 -top-16 size-64 rounded-full bg-primary/25 blur-3xl" />
        <div className="relative mx-auto max-w-2xl">
          <h2 className="text-3xl font-bold text-ink-foreground sm:text-4xl">{title}</h2>
          <p className="mt-4 text-ink-foreground/75">{text}</p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Button asChild variant="hero" size="xl">
              <Link to="/offert">
                Begär kostnadsfri offert <ArrowRight className="size-5" />
              </Link>
            </Button>
            <Button asChild variant="onInk" size="xl">
              <a href="tel:025042277">
                <Phone className="size-5" /> 0250-422 77
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
