import type { ReactNode } from "react";

export function PageHero({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  children?: ReactNode;
}) {
  return (
    <section className="ink-section relative overflow-hidden">
      <div className="pointer-events-none absolute -left-20 top-0 size-72 rounded-full bg-primary/20 blur-3xl" />
      <div className="container-px relative py-16 sm:py-20">
        <div className="max-w-3xl">
          {eyebrow && <p className="eyebrow justify-start text-primary-glow">{eyebrow}</p>}
          <h1 className="mt-4 text-4xl font-bold leading-tight text-ink-foreground sm:text-5xl">
            {title}
          </h1>
          {description && (
            <p className="mt-5 max-w-2xl text-lg leading-relaxed text-ink-foreground/75">
              {description}
            </p>
          )}
          {children && <div className="mt-8">{children}</div>}
        </div>
      </div>
    </section>
  );
}
