import { Star, BadgeCheck } from "lucide-react";
import { testimonials } from "@/data/projects";
import { SectionHeading } from "./SectionHeading";

export function Testimonials() {
  return (
    <section className="py-20">
      <div className="container-px">
        <SectionHeading
          eyebrow="Kundomdömen"
          title="Vad våra kunder säger"
          description="Vi är stolta över förtroendet från privatpersoner och företag i hela Dalarna."
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {testimonials.map((t) => (
            <figure
              key={t.name}
              className="flex flex-col rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)]"
            >
              <div className="flex gap-0.5" aria-label={`${t.rating} av 5 stjärnor`}>
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} className="size-4 fill-[oklch(0.82_0.16_85)] text-[oklch(0.82_0.16_85)]" />
                ))}
              </div>
              <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-foreground/85">
                “{t.text}”
              </blockquote>
              <figcaption className="mt-5 flex items-center justify-between border-t border-border pt-4">
                <div>
                  <p className="text-sm font-semibold">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.location}</p>
                </div>
                <span className="inline-flex items-center gap-1 text-xs font-medium text-success">
                  <BadgeCheck className="size-4" /> Verifierad
                </span>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
